import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

interface CarMake {
  make_display: string;
  make_slug: string;
}

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './carlist.html',
  styleUrl: './carlist.css',
})
export class Carlist implements OnInit {
  carMakes: CarMake[] = [];
  selectedMake: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchCarMakes();
  }

  fetchCarMakes(): void {
    const url = 'https://www.carqueryapi.com/api/0.3/?callback=?&cmd=getMakes';

    this.http.jsonp(url, 'callback').subscribe({
      next: (res: any) => {
        this.carMakes = res.Makes;
      },
      error: (err) => {
        console.error('Error fetching car makes', err);
      }
    });
  }

  onSelectMake(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.selectedMake = target.value;
    console.log('Selected car make:', this.selectedMake);
  }
}

