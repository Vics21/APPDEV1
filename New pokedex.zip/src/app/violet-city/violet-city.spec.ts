import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VioletCity } from './violet-city';

describe('VioletCity', () => {
  let component: VioletCity;
  let fixture: ComponentFixture<VioletCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VioletCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VioletCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
