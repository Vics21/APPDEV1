import { Component } from '@angular/core';

@Component({
  selector: 'app-olivine-city',
  imports: [],
  templateUrl: './olivine-city.html',
  styleUrl: './olivine-city.css'
})
export class OlivineCity {
  leader = 'Clair';
  specialty = 'Dragon';
  badge = 'Rising Badge';
  pokemon = 'Dragonair, ' + 'Gyarados, ' + 'Kingdra';
}
