import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OlivineCity } from './olivine-city';

describe('OlivineCity', () => {
  let component: OlivineCity;
  let fixture: ComponentFixture<OlivineCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OlivineCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OlivineCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
