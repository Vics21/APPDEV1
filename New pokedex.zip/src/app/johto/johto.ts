import { Component } from '@angular/core';
import { LegendaryPokemon } from '../legendary-pokemon';

@Component({
  selector: 'app-johto',
  imports: [],
  templateUrl: './johto.html',
  styleUrl: './johto.css'
})
export class Johto {
johtoImage: {name: string; image:string}[] = [];
johtoLore: string[] = [];

constructor(private pokemonService: LegendaryPokemon){}

ngOnInit(): void{
this.johtoLore = 
this.pokemonService.getJohtoLore();
this.johtoImage = 
this.pokemonService.getJohtoImage();
}
}