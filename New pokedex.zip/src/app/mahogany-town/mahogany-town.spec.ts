import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MahoganyTown } from './mahogany-town';

describe('MahoganyTown', () => {
  let component: MahoganyTown;
  let fixture: ComponentFixture<MahoganyTown>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MahoganyTown]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MahoganyTown);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
