import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterModule} from '@angular/router';
import { Recommend } from './recommend/recommend';
import { Navbar } from './navbar/navbar';
import { Customization } from './customization/customization';
import { Comparison } from './comparison/comparison';
import { Carlist } from './carlist/carlist';
import { CarSearch } from './car-search/car-search';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterModule, Recommend, Navbar, Customization, Comparison, Carlist, CarSearch],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('car');
}
