import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CarsService, CarModel, CarMaker } from '../cars-service';

interface CarMake {
  make_display: string;
  make_slug: string;
}

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './carlist.html',
  styleUrl: './carlist.css',
})
export class Carlist implements OnInit {
  carMakers: CarMaker[] = [];
  carModels: CarModel[] = [];
  selectedMaker: string = '';

  constructor(private carsService: CarsService) {}

  ngOnInit(): void {
    this.loadCarMakers();
  }

  loadCarMakers() {
    this.carMakers = this.carsService.getCarMakers();
    console.log('Loaded makers:', this.carMakers.length);
  }

  onMakerChange() {
    if (!this.selectedMaker) {
      this.carModels = [];
      return;
    }
    
    this.carModels = this.carsService.getModelsForMaker(this.selectedMaker);
    console.log('Showing models for', this.selectedMaker, ':', this.carModels);
  }
}
