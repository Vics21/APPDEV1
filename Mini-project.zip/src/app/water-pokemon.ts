import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WaterPokemon {
  constructor(){}
  
  getTotodile(){
    return [{
     Health: 50, 
     Attack: 65,
     Defense: 64,
     SpecialAtk: 44,
     SpecialDef: 48,
     Speed: 43,
     Typing: 'Water',
    }];
  }
  getCroconaw(){
    return [{
     Health: 65, 
     Attack: 80,
     Defense: 80,
     SpecialAtk: 59,
     SpecialDef: 63,
     Speed: 58,
     Typing: 'Water',
    }];
  }
  getFeraligatr(){
    return [{
     Health: 85, 
     Attack: 105,
     Defense: 100,
     SpecialAtk: 79,
     SpecialDef: 83,
     Speed: 78,
     Typing: 'Water',
    }];
  }
}
