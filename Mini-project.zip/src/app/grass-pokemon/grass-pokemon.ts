import { Component } from '@angular/core';
import { GrassPokemon } from '../grass-pokemon'

@Component({
  selector: 'app-grass-pokemon',
  imports: [],
  templateUrl: './grass-pokemon.html',
  styleUrl: './grass-pokemon.css'
})
export class GrassPokemon {
  grass: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string[] }[] = [];

  constructor(private grassService: GrassPokemon) {}

  ngOnInit(): void {
    this.grass = this.grassService.getChikorita();
    this.grass = this.grassService.getBayleef();
    this.grass = this.grassService.getMeganium();
  }
}
