import { Component } from '@angular/core';
import { FirePokemon } from '../fire-pokemon'

@Component({
  selector: 'app-fire-pokemon',
  imports: [],
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
  fire: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string[] }[] = [];

  constructor(private fireService: FirePokemon) {}

  ngOnInit(): void {
    this.fire = this.fireService.getCyndaquil();
    this.fire = this.fireService.getQuilava();
    this.fire = this.fireService.getTyphlosion();
  }
}
