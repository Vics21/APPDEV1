import { Component } from '@angular/core';
import { WaterPokemon } from '../water-pokemon'

@Component({
  selector: 'app-water-pokemon',
  imports: [],
  templateUrl: './water-pokemon.html',
  styleUrl: './water-pokemon.css'
})
export class WaterPokemon {
  water: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string[] }[] = [];

  constructor(private waterService: WaterPokemon) {}
  
  ngOnInit(): void {
    this.water = this.waterService.getTotodile();
    this.water = this.waterService.getCroconaw();
    this.water = this.waterService.getFeraligatr();
  }
}
