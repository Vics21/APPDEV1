import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-recommend',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './recommend.html',
  styleUrl: './recommend.css',
})
export class Recommend {

}
