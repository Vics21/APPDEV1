import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customization',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './customization.html',
  styleUrl: './customization.css',
})
export class Customization {

}
