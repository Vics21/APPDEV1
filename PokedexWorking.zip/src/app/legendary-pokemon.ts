import { Injectable } from '@angular/core';

@Injectable({
providedIn: 'root'//The service is available through out the application
})

export class LegendaryPokemon {
constructor() {
}
getKantoLegendaries(){
return [
{ name: 'Articuno', type: 'Ice/Flying' },
{ name: 'Zapdos', type: 'Electric/Flying' },
{ name: 'Moltres', type: 'Fire/Flying' },
{ name: 'Mewtwo', type: 'Psychic' },
{ name: 'Mew', type: 'Psychic' }
];
}
getJohtoLegendaries() {
return [
{ name: 'Raikou', type: 'Electric' },
{ name: 'Entei', type: 'Fire' },
{ name: 'Suicune', type: 'Water' },
{ name: 'Lugia', type: 'Psychic/Flying' },
{ name: 'Ho-Oh', type: 'Fire/Flying' },
{ name: 'Celebi', type: 'Psychic/Grass' }
];
}
getJohtoLore() {
return [
    "The Johto region (Japanese: ジョウト地方 Johto region) is a region of the Pokémon world. Johto is located west of Kanto, which together form a joint landmass that is south of Sinnoh and Sinjoh Ruins.",
    "It was the second core series region to be introduced. First explored in Pokémon Gold and Silver, it is home to an additional 100 Pokémon that were not present in the previous games. It is also the setting of Pokémon Crystal, Pokémon HeartGold, and Pokémon SoulSilver.",
    "Players begin their journey in New Bark Town, where Professor Elm offers either Chikorita, Cyndaquil, or Totodile to beginning Pokémon Trainers.",
    "The English-version names of most of the cities in Johto are names of plants or things related to plants."
];
}
}