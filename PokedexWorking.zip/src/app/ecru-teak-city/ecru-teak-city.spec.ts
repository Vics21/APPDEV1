import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcruTeakCity } from './ecru-teak-city';

describe('EcruTeakCity', () => {
  let component: EcruTeakCity;
  let fixture: ComponentFixture<EcruTeakCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EcruTeakCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EcruTeakCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
