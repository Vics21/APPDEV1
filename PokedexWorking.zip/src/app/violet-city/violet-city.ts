import { Component } from '@angular/core';

@Component({
  selector: 'app-violet-city',
  imports: [],
  templateUrl: './violet-city.html',
  styleUrl: './violet-city.css'
})
export class VioletCity {
  leader = 'Falkner';
  specialty = 'Flying';
  badge = 'Zephyr Badge';
  pokemon = 'Pidgey,' + ' Pidgeotto';
}
