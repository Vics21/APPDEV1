import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GoldenRodCity } from './golden-rod-city';

describe('GoldenRodCity', () => {
  let component: GoldenRodCity;
  let fixture: ComponentFixture<GoldenRodCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GoldenRodCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GoldenRodCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
