import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AzaleaTown } from './azalea-town';

describe('AzaleaTown', () => {
  let component: AzaleaTown;
  let fixture: ComponentFixture<AzaleaTown>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AzaleaTown]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AzaleaTown);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
