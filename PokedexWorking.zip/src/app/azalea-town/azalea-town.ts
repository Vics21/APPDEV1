import { Component } from '@angular/core';

@Component({
  selector: 'app-azalea-town',
  imports: [],
  templateUrl: './azalea-town.html',
  styleUrl: './azalea-town.css'
})
export class AzaleaTown {
  leader = 'Bugsy';
  specialty = 'Bug';
  badge = 'Hive Badge';
  pokemon = 'Metapod, ' + 'Kakuna, ' + ' Scyther';
}

