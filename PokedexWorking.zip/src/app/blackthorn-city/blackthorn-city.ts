import { Component } from '@angular/core';

@Component({
  selector: 'app-blackthorn-city',
  imports: [],
  templateUrl: './blackthorn-city.html',
  styleUrl: './blackthorn-city.css'
})
export class BlackThornCity {
  leader = 'Whitney';
  specialty = 'Normal';
  badge = 'Plain Badge';
  pokemon = 'Clefairy, ' + 'Miltank';
}
