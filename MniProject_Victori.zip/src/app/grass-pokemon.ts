import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GrassPokemon {
  constructor(){}
  
  getChikorita(){
    return [{ Health: 45, Attack: 49, Defense: 65, SpecialAtk: 49, SpecialDef: 65, Speed: 45, Typing: 'Grass' }];
  }
  getBayleef(){
    return [{ Health: 60, Attack: 62, Defense: 80, SpecialAtk: 63, SpecialDef: 80, Speed: 60, Typing: 'Grass' }];
  }
  getMeganium(){
    return [{ Health: 80, Attack: 82, Defense: 100, SpecialAtk: 83, SpecialDef: 100, Speed: 80,Typing: 'Grass' }];
  }
}

