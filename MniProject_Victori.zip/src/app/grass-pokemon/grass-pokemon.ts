import { Component } from '@angular/core';
import { GrassPokemon } from '../grass-pokemon'

@Component({
  selector: 'app-grass-pokemon',
  imports: [],
  templateUrl: './grass-pokemon.html',
  styleUrl: './grass-pokemon.css'
})
export class Grass {
  constructor(private grassService: GrassPokemon) {}
  
  grass: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string }[] = [];

  ngOnInit(): void {
    this.OGpokemon();
  }

  OGpokemon(): void {
    this.grass = this.grassService.getBayleef();
  }

  evolve1(): void {
    this.grass = this.grassService.getChikorita();
  }

  evolve2(): void {
    this.grass = this.grassService.getMeganium();
  }
}
