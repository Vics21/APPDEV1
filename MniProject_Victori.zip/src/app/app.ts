import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Water } from './water-pokemon/water-pokemon';
import { Grass } from './grass-pokemon/grass-pokemon';
import { Fire } from './fire-pokemon/fire-pokemon';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Water, Grass, Fire],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Mini-Project1');
}
