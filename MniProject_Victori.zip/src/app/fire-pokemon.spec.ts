import { TestBed } from '@angular/core/testing';

import { FirePokemon } from './fire-pokemon';

describe('FirePokemon', () => {
  let service: FirePokemon;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirePokemon);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
