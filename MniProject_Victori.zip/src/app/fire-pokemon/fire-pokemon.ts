import { Component } from '@angular/core';
import { FirePokemon } from '../fire-pokemon'

@Component({
  selector: 'app-fire-pokemon',
  imports: [],
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class Fire {
  constructor(private FireService: FirePokemon) {}
  
  fire: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string }[] = [];

  ngOnInit(): void {
    this.OGpokemon();
  }

  OGpokemon(): void {
    this.fire = this.FireService.getCyndaquil();
  }

  evolve1(): void {
    this.fire = this.FireService.getQuilava();
  }

  evolve2(): void {
    this.fire = this.FireService.getTyphlosion();
  }
}

