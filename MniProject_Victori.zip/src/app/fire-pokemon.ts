import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirePokemon {
  constructor(){}
  
  getCyndaquil(){
    return [{ Health: 39, Attack: 52, Defense: 43, SpecialAtk: 60, SpecialDef: 50, Speed: 65, Typing: 'Fire' }];
  }
  getQuilava(){
    return [{ Health: 58, Attack: 64, Defense: 58, SpecialAtk: 80, SpecialDef: 65, Speed: 80, Typing: 'Fire' }];
  }
  getTyphlosion(){
    return [{ Health: 78, Attack: 84, Defense: 78, SpecialAtk: 109, SpecialDef: 85, Speed: 100, Typing: 'Fire' }];
  }
}

