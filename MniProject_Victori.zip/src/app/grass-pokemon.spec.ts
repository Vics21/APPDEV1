import { TestBed } from '@angular/core/testing';

import { GrassPokemon } from './grass-pokemon';

describe('GrassPokemon', () => {
  let service: GrassPokemon;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GrassPokemon);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
