import { Component } from '@angular/core';
import { WaterPokemon } from '../water-pokemon'

@Component({
  selector: 'app-water-pokemon',
  imports: [],
  templateUrl: './water-pokemon.html',
  styleUrl: './water-pokemon.css'
})
export class Water {
  constructor(private waterService: WaterPokemon) {}
  
  water: { Health: number; Attack: number; Defense: number; SpecialAtk: number; SpecialDef: number; Speed: number; Typing: string }[] = [];

  ngOnInit(): void {
    this.OGpokemon();
  }

  OGpokemon(): void {
    this.water = this.waterService.getTotodile();
    this.currentStage = 1;
  }

  evolve1(): void {
    this.water = this.waterService.getCroconaw();
    this.currentStage = 2;
  }

  evolve2(): void {
    this.water = this.waterService.getFeraligatr();
    this.currentStage = 3;
  }
}

