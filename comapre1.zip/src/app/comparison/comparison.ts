import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface CarModel {
  Model_Name: string;
  imageUrl: string;
}

interface CarSpecs {
  engineType: string;
  maxTorque: string;
  topSpeed: string;
}

interface SelectedCar {
  brand: string;
  model: string;
  imageUrl: string;
  price: string;
  specs: CarSpecs;
}

@Component({
  selector: 'app-comparison',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './comparison.html',
  styleUrls: ['./comparison.css']
})
export class Comparison {
  carDatabase: { [key: string]: CarModel[] } = {
    'TOYOTA': [
      { Model_Name: 'Camry', imageUrl: 'camry.png' },
      { Model_Name: 'Supra', imageUrl: 'Supra.png' },
      { Model_Name: 'Fortuner', imageUrl: 'fortuner.png' }
    ],
    'HONDA': [
      { Model_Name: 'Civic Type R', imageUrl: 'civictyper.png' },
      { Model_Name: 'City', imageUrl: 'city.jpeg' },
      { Model_Name: 'Brio', imageUrl: 'brio.png' }
    ],
    'FORD': [
      { Model_Name: 'Raptor', imageUrl: 'raptor.png' },
      { Model_Name: 'Mustang', imageUrl: 'mustang.png' },
      { Model_Name: 'Territory', imageUrl: 'territory.png' }
    ],
    'TESLA': [
      { Model_Name: 'Cybertruck', imageUrl: 'cybertruck.png' },
      { Model_Name: 'Model S', imageUrl: 'models.png' },
      { Model_Name: 'Model Y', imageUrl: 'modely.png' }
    ],
    'BMW': [
      { Model_Name: 'M2 Coupe', imageUrl: 'm2coupe.png' },
      { Model_Name: 'Z4 Roadster', imageUrl: 'z4roadster.png' },
      { Model_Name: 'i7', imageUrl: 'i7.png' }
    ],
    'MERCEDES-BENZ': [
      { Model_Name: 'G-Class', imageUrl: 'g-class.png' },
      { Model_Name: 'Maybach S-Class', imageUrl: 'maybachs-class.png' },
      { Model_Name: 'S-Class', imageUrl: 's-class.png' }
    ],
    'CHEVROLET': [
      { Model_Name: 'Corvette', imageUrl: 'corvette.png' },
      { Model_Name: 'Tahoe', imageUrl: 'tahoe.png' },
      { Model_Name: 'Trailblazer', imageUrl: 'trailblazer.png' }
    ],
    'NISSAN': [
      { Model_Name: 'Terra', imageUrl: 'terra.png' },
      { Model_Name: 'Leaf', imageUrl: 'leaf.png' },
      { Model_Name: 'GT-R', imageUrl: 'gtr.png' }
    ],
    'AUDI': [
      { Model_Name: 'R8', imageUrl: 'r8.png' },
      { Model_Name: 'Q8', imageUrl: 'q8.png' },
      { Model_Name: 'E-Tron GT', imageUrl: 'etrongt.png' }
    ],
    'PORSCHE': [
      { Model_Name: '911 Turbo S', imageUrl: '911turbos.png' },
      { Model_Name: 'Cayenne', imageUrl: 'cayenne.png' },
      { Model_Name: 'Macan', imageUrl: 'macan.png' }
    ],
    'Mitsubishi': [
      { Model_Name: 'Montero Sport', imageUrl: 'monterosport.png' },
      { Model_Name: 'Triton', imageUrl: 'triton.png' },
      { Model_Name: 'Xpander', imageUrl: 'xpander.png' }
    ],
    'Lamborghini': [
      { Model_Name: 'Revuelto', imageUrl: 'revuelto.png' },
      { Model_Name: 'Huracan', imageUrl: 'huracan.png' },
      { Model_Name: 'Urus', imageUrl: 'urus.png' }
    ],
    'Subaru': [
      { Model_Name: 'BRZ', imageUrl: 'brz.png' },
      { Model_Name: 'WRX STI', imageUrl: 'wrxsti.png' },
      { Model_Name: 'OUTBACK', imageUrl: 'outback.png' }
    ],
    'Ferrari': [
      { Model_Name: 'SF90', imageUrl: 'sf90.png' },
      { Model_Name: 'F12', imageUrl: 'f12.png' },
      { Model_Name: 'SP3', imageUrl: 'sp3.png' }
    ],
    'Rolls Royce': [
      { Model_Name: 'Cullinan', imageUrl: 'cullinan.png' },
      { Model_Name: 'Phantom', imageUrl: 'phantom.png' },
      { Model_Name: 'Spectre', imageUrl: 'spectre.png' }
    ]
  };

  brands: string[] = Object.keys(this.carDatabase);
  
  selectedBrand1: string = 'TOYOTA';
  selectedBrand2: string = 'HONDA';
  selectedModel1: string = 'Camry';
  selectedModel2: string = 'Civic Type R';

  showSelector1: boolean = false;
  showSelector2: boolean = false;

  expandedSections: { [key: string]: boolean } = {
    'engine': true,
    'performance': false
  };

  car1: SelectedCar = {
    brand: 'TOYOTA',
    model: 'Camry',
    imageUrl: 'assets/camry.png',
    price: '1,500,000',
    specs: {
      engineType: '4-Cylinder In-line',
      maxTorque: '231 Nm / 4,100 rpm',
      topSpeed: '200 km/h'
    }
  };

  car2: SelectedCar = {
    brand: 'HONDA',
    model: 'Civic Type R',
    imageUrl: 'assets/civictyper.png',
    price: '2,950,000',
    specs: {
      engineType: '4-Cylinder Turbocharged',
      maxTorque: '420 Nm / 2,600-4,000 rpm',
      topSpeed: '272 km/h'
    }
  };

  getModelsForBrand(brand: string): CarModel[] {
    return this.carDatabase[brand] || [];
  }

  openSelector(carNumber: number): void {
    if (carNumber === 1) {
      this.showSelector1 = true;
      this.showSelector2 = false;
    } else {
      this.showSelector2 = true;
      this.showSelector1 = false;
    }
  }

  selectCar(carNumber: number): void {
    if (carNumber === 1) {
      const selectedCarModel = this.carDatabase[this.selectedBrand1].find(
        car => car.Model_Name === this.selectedModel1
      );
      if (selectedCarModel) {
        this.car1 = {
          brand: this.selectedBrand1,
          model: this.selectedModel1,
          imageUrl: `assets/${selectedCarModel.imageUrl}`,
          price: this.getEstimatedPrice(this.selectedBrand1, this.selectedModel1),
          specs: this.getCarSpecs(this.selectedBrand1, this.selectedModel1)
        };
      }
      this.showSelector1 = false;
    } else {
      const selectedCarModel = this.carDatabase[this.selectedBrand2].find(
        car => car.Model_Name === this.selectedModel2
      );
      if (selectedCarModel) {
        this.car2 = {
          brand: this.selectedBrand2,
          model: this.selectedModel2,
          imageUrl: `assets/${selectedCarModel.imageUrl}`,
          price: this.getEstimatedPrice(this.selectedBrand2, this.selectedModel2),
          specs: this.getCarSpecs(this.selectedBrand2, this.selectedModel2)
        };
      }
      this.showSelector2 = false;
    }
  }

  cancelSelection(carNumber: number): void {
    if (carNumber === 1) {
      this.showSelector1 = false;
    } else {
      this.showSelector2 = false;
    }
  }

  toggleSection(section: string): void {
    this.expandedSections[section] = !this.expandedSections[section];
  }

  getEstimatedPrice(brand: string, model: string): string {
    const priceMap: { [key: string]: string } = {
      'TOYOTA-Camry': '1,500,000',
      'TOYOTA-Supra': '5,690,000',
      'TOYOTA-Fortuner': '2,656,000',
      'HONDA-Civic Type R': '2,950,000',
      'HONDA-City': '1,050,000',
      'HONDA-Brio': '750,000',
      // Add more as needed
    };
    return priceMap[`${brand}-${model}`] || 'Price TBD';
  }

  getCarSpecs(brand: string, model: string): CarSpecs {
    return {
      engineType: '4-Cylinder',
      maxTorque: '200 Nm / 4,000 rpm',
      topSpeed: '180 km/h'
    };
  }
}