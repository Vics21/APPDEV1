import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-olivine-city',
  imports: [],
  templateUrl: './olivine-city.html',
  styleUrl: './olivine-city.css'
})
export class OlivineCity {
  olivineCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.olivineCity = this.leadersService.getOlivineCity();
  }
}
