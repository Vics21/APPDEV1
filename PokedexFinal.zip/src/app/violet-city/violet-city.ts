import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-violet-city',
  imports: [],
  templateUrl: './violet-city.html',
  styleUrl: './violet-city.css'
})
export class VioletCity {
  violetCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.violetCity = this.leadersService.getVioletCity();
  }
}