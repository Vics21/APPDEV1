import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-azalea-town',
  imports: [],
  templateUrl: './azalea-town.html',
  styleUrl: './azalea-town.css'
})
export class AzaleaTown {
  azaleaTown: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.azaleaTown = this.leadersService.getAzaleaTown();
  }
}

