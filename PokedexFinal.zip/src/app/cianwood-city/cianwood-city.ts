import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-cianwood-city',
  imports: [],
  templateUrl: './cianwood-city.html',
  styleUrl: './cianwood-city.css'
})
export class CianwoodCity {
  cianwoodCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.cianwoodCity = this.leadersService.getCianwoodCity();
  }
}