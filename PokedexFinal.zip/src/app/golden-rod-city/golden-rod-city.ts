import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-golden-rod-city',
  imports: [],
  templateUrl: './golden-rod-city.html',
  styleUrl: './golden-rod-city.css'
})
export class GoldenRodCity {
  goldenRodCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.goldenRodCity = this.leadersService.getGoldenRodCity();
  }
}