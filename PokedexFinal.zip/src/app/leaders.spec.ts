import { TestBed } from '@angular/core/testing';

import { Leaders } from './leaders';

describe('Leaders', () => {
  let service: Leaders;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Leaders);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
