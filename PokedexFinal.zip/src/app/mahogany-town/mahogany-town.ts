import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-mahogany-town',
  imports: [],
  templateUrl: './mahogany-town.html',
  styleUrl: './mahogany-town.css'
})
export class MahoganyTown {
  mahoganyTown: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.mahoganyTown = this.leadersService.getMahoganyTown();
  }
}
