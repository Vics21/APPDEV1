import { Injectable } from '@angular/core';

export interface Trainer {
  id: string; // uuid-ish
  name: string;
  age: number;
  address: string;
  team: string[]; // array of pokemon names (max 6)
  createdAt: number;
}

@Injectable({
  providedIn: 'root'
})
export class TrainerService {
   private storageKey = 'pokedex_trainers';

  constructor() {}

  getAll(): Trainer[] {
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (!raw) return [];
      return JSON.parse(raw) as Trainer[];
    } catch {
      return [];
    }
  }

  saveAll(trainers: Trainer[]) {
    localStorage.setItem(this.storageKey, JSON.stringify(trainers));
  }

  add(trainer: Omit<Trainer, 'id' | 'createdAt'>) {
    const trainers = this.getAll();
    const newT: Trainer = {
      id: (Date.now() + Math.random()).toString(36),
      createdAt: Date.now(),
      ...trainer
    };
    trainers.unshift(newT);
    this.saveAll(trainers);
    return newT;
  }

  delete(id: string) {
    const trainers = this.getAll().filter(t => t.id !== id);
    this.saveAll(trainers);
    return trainers;
  }

  clearAll() {
    localStorage.removeItem(this.storageKey);
  }
}