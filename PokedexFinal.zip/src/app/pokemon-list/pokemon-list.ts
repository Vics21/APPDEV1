import { Component } from '@angular/core';
import { LegendaryPokemon } from '../legendary-pokemon';

@Component({
selector: 'app-pokemon-list',
standalone: true,
imports: [],
templateUrl: './pokemon-list.html',
styleUrl: './pokemon-list.css'
})

export class PokemonList {
kantoLegendaries: { name: string; type: string }[] = [];
johtoLegendaries: { name: string; type: string }[] = [];

constructor(private pokemonService: LegendaryPokemon){}

ngOnInit(): void{
this.kantoLegendaries =
this.pokemonService.getKantoLegendaries();
this.johtoLegendaries =
this.pokemonService.getJohtoLegendaries(); 
  }
}

