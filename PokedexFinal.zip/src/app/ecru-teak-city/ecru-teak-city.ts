import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-ecru-teak-city',
  imports: [],
  templateUrl: './ecru-teak-city.html',
  styleUrl: './ecru-teak-city.css'
})
export class EcruTeakCity {
  ecruTeakCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.ecruTeakCity = this.leadersService.getEcruteakCity();
  }
}
