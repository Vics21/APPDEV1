import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LeadersService {

  constructor() {}

  getVioletCity() {
    return [{
        city: 'Violet City',
        leader: 'Falkner',
        type: 'Flying-type',
        badge: 'Zephyr Badge',
        pokemons: ['Pidgey', 'Pidgeotto', 'Noctowl']
      }];
      }
  getAzaleaTown() {
    return [{
        city: 'Azalea Town',
        leader: 'Bugsy',
        type: 'Bug-type',
        badge: 'Hive Badge',
        pokemons: ['Weedle', 'Kakuna', 'Scyther']
      }];
      }
  getGoldenRodCity() {
    return [{
        city: 'Goldenrod City',
        leader: 'Whitney',
        type: 'Normal-type',
        badge: 'Plain Badge',
        pokemons: ['Clefairy', 'Miltank']
      }];
      }
  getEcruteakCity() {
    return [{
        city: 'Ecruteak City',
        leader: 'Morty',
        type: 'Ghost-type',
        badge: 'Fog Badge',
        pokemons: ['Gastly', 'Haunter', 'Gengar']
      }];
      }
  getCianwoodCity() {
    return [{
        city: 'Cianwood City',
        leader: 'Chuck',
        type: 'Fighting-type',
        badge: 'Storm Badge',
        pokemons: ['Primeape', 'Poliwrath']
      }];
      }
  getOlivineCity() {
    return [{
        city: 'Olivine City',
        leader: 'Jasmine',
        type: 'Steel-type',
        badge: 'Mineral Badge',
        pokemons: ['Magnemite', 'Steelix']
      }];
      }
  getMahoganyTown() {
    return [{
        city: 'Mahogany Town',
        leader: 'Pryce',
        type: 'Ice-type',
        badge: 'Glacier Badge',
        pokemons: ['Swinub', 'Piloswine']
      }];
      }
  getBlackthornCity() {
    return [{
        city: 'Blackthorn City',
        leader: 'Clair',
        type: 'Dragon-type',
        badge: 'Rising Badge',
        pokemons: ['Dragonair', 'Kingdra', 'Gyarados']
      }];
      }
  }
