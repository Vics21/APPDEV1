import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TrainerService, Trainer } from '../trainer';

@Component({
  selector: 'app-trainer-registration',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './registration.html',
  styleUrls: ['./registration.css']
})
export class TrainerRegistration implements OnInit {

  form: any;
  trainers: Trainer[] = [];
  teamError = '';

  constructor(private fb: FormBuilder, private trainerService: TrainerService) {
    this.load();
  }
  
  ngOnInit(): void {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      age: [null, [Validators.required, Validators.min(10)]],
      address: ['', Validators.required],
      teamText: ['', Validators.required]
    });
  }
    private load() {
    this.trainers = this.trainerService.getAll();
  }
  
 parseTeam(text: string): string[] {
    // split on commas, semicolons or newlines; trim and filter empties
    const parts = text
      .split(/[,;\n]+/)
      .map(p => p.trim())
      .filter(p => p.length > 0)
      .slice(0, 6); // keep up to 6
    return parts;
  }

  onSubmit() {
    this.teamError = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const team = this.parseTeam(this.form.value.teamText || '');
    if (team.length === 0) {
      this.teamError = 'Please add at least one Pokémon to the team.';
      return;
    }
    if (team.length > 6) {
      this.teamError = 'Please provide up to 6 Pokémon only.';
      return;
    }

    const trainer = this.trainerService.add({
      name: (this.form.value.name || '').trim(),
      age: Number(this.form.value.age),
      address: (this.form.value.address || '').trim(),
      team
    });

    // Refresh list and reset form (keep easy defaults)
    this.trainers = this.trainerService.getAll();
    this.form.reset();
    // keep validation message cleared
    this.teamError = '';
  }

  deleteTrainer(id: string) {
    this.trainerService.delete(id);
    this.load();
  }

  clearAll() {
    if (!confirm('Clear all trainers? This cannot be undone.')) return;
    this.trainerService.clearAll();
    this.load();
  }

  // helpers for template
  trackById(index: number, item: Trainer) {
    return item.id;
  }
}

