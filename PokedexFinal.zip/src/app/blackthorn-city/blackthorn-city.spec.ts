import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlackthornCity } from './blackthorn-city';

describe('BlackthornCity', () => {
  let component: BlackthornCity;
  let fixture: ComponentFixture<BlackthornCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BlackthornCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BlackthornCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
