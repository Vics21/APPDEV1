import { Component } from '@angular/core';
import { LeadersService } from '../leaders';

@Component({
  selector: 'app-blackthorn-city',
  imports: [],
  templateUrl: './blackthorn-city.html',
  styleUrl: './blackthorn-city.css'
})
export class BlackThornCity {
  blackThornCity: { city: string; leader: string; type: string; badge: string; pokemons: string[] }[] = [];

  constructor(private leadersService: LeadersService) {}

  ngOnInit(): void {
    this.blackThornCity = this.leadersService.getBlackthornCity();
  }
}
