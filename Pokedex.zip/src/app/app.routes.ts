import { Routes } from '@angular/router'
import { VioletCity } from './violet-city/violet-city';
import { AzaleaTown } from './azalea-town/azalea-town';
import { GoldenRodCity } from './golden-rod-city/golden-rod-city';
import { EcruTeakCity } from './ecru-teak-city/ecru-teak-city';
import { CianwoodCity } from './cianwood-city/cianwood-city';
import { OlivineCity } from './olivine-city/olivine-city';
import { MahoganyTown } from './mahogany-town/mahogany-town';
import { BlackThornCity } from './blackthorn-city/blackthorn-city';
import { PokemonList } from './pokemon-list/pokemon-list'

export const routes: Routes =[
    {
        path:'azalea', component: AzaleaTown
    },
    {
        path:'blackthorn', component: BlackThornCity
    },
    {
        path:'cianwood', component: CianwoodCity
    },
    {
        path:'ecruteak', component: EcruTeakCity
    },
    {
        path:'goldenrod', component: GoldenRodCity
    },
    {
        path:'mahogany', component: MahoganyTown
    },
    {
        path:'olivine', component: OlivineCity
    },
    {
        path:'violet', component: VioletCity
    },
    {
        path:'pokemon', component: PokemonList
    },
];
