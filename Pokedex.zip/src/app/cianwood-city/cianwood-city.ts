import { Component } from '@angular/core';

@Component({
  selector: 'app-cianwood-city',
  imports: [],
  templateUrl: './cianwood-city.html',
  styleUrl: './cianwood-city.css'
})
export class CianwoodCity {
  leader = 'Morty';
  specialty = 'Ghost';
  badge = 'Fog Badge';
  pokemon = 'Gastly, ' + 'Haunter, ' + 'Gengar';
}
