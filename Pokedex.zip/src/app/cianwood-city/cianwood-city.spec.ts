import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CianwoodCity } from './cianwood-city';

describe('CianwoodCity', () => {
  let component: CianwoodCity;
  let fixture: ComponentFixture<CianwoodCity>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CianwoodCity]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CianwoodCity);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
