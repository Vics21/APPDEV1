import { Component } from '@angular/core';

@Component({
  selector: 'app-golden-rod-city',
  imports: [],
  templateUrl: './golden-rod-city.html',
  styleUrl: './golden-rod-city.css'
})
export class GoldenRodCity {
  leader = 'Jasmine';
  specialty = 'Steel';
  badge = 'Mineral Badge';
  pokemon = 'Magnemite, ' + 'Steelix';
}
