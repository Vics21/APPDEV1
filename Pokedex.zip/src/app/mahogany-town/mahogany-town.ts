import { Component } from '@angular/core';

@Component({
  selector: 'app-mahogany-town',
  imports: [],
  templateUrl: './mahogany-town.html',
  styleUrl: './mahogany-town.css'
})
export class MahoganyTown {
  leader = 'Pryce';
  specialty = 'Ice';
  badge = 'Glacier Badge';
  pokemon = 'Seel, ' + 'Dewgong, ' + 'Piloswine';
}
