import { Component } from '@angular/core';

@Component({
  selector: 'app-ecru-teak-city',
  imports: [],
  templateUrl: './ecru-teak-city.html',
  styleUrl: './ecru-teak-city.css'
})
export class EcruTeakCity {
  leader = 'Chuck';
  specialty = 'Fighting';
  badge = 'Storm Badge';
  pokemon = 'Primeape, ' + 'Poliwrath';
}
