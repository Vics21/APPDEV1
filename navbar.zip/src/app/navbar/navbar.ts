import { Component} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Carlist } from '../carlist/carlist';
import { Comparison } from '../comparison/comparison';
import { Recommend } from '../recommend/recommend';
import { Customization } from '../customization/customization';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
Links = [
    {path: 'car-list', component: Carlist},
    {path: 'comparison', component: Comparison},
    {path: 'recommend', component: Recommend},
    {path: 'customization', component: Customization},
  ];
}
