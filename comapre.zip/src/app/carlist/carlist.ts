import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface CarMake {
  make_display: string;
  make_slug: string;
}

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './carlist.html',
  styleUrl: './carlist.css',
})
export class Carlist {

}

