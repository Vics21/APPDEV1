import { Routes } from '@angular/router';
import { Carlist } from './carlist/carlist';
import { Comparison } from './comparison/comparison';
import { Recommend } from './recommend/recommend';
import { Customization } from './customization/customization';
import { Searchbar } from './searchbar/searchbar';

export const routes: Routes = [
  { path: 'carlist', component: Carlist },
  { path: 'comparison', component: Comparison },
  { path: 'recommend', component: Recommend },
  { path: 'customization', component: Customization },
  { path: 'search', component: Searchbar },
];